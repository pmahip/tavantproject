import { Component } from '@angular/core';

@Component({
    selector: 'pm-sales',
    template: `
       <div class="alert alert-dismissible alert-success">
                
                <strong>Coming soon....</strong>
              </div>
    `
})

export class SalesComponent { }